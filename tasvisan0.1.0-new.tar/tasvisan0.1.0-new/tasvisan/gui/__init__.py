# -*- coding: utf-8 -*-
"""
Created on Thu Jan 30 13:27:29 2020
@author: dgc
"""

from .TASDataBrowser import main
